# Question 1: Using a for loop with a list

# TODO: Create a list of fruits
fruits = ['bannana', 'apple','orange']
# TODO: Use a for loop to print each fruit in the list
for x in fruits:
  print(x)

#-------------------------------------------------------------------------
# Question 2: Using a while loop for countdown

# TODO: Use a while loop to create a countdown from 5 to 1
i = 5
while i>0:
  print(i)
  i -= 1

#-------------------------------------------------------------------------
# Question 3: Using a for loop with range()

# TODO: Use a for loop to print the first 10 square numbers
for number in range(1,11):
  print(number**2)

#-------------------------------------------------------------------------

# Question 4: Using the random module

# TODO: Import the random module
import random
# TODO: Create a list of colors
colors = ['red', 'blue', 'green', 'orange', 'purple']
# TODO: Use a for loop to select and print 3 random colors from the list
num_of_colors = 3
for _ in range(num_of_colors):
  color = random.choice(colors)
  print(color)

#-------------------------------------------------------------------------
# Question 5: Creating and using a custom module

# TODO: Create a new file named 'math_operations.py' with the following content:
"""
def add(a, b):
    return a + b

def subtract(a, b):
    return a - b

def multiply(a, b):
    return a * b

def divide(a, b):
    if b != 0:
        return a / b
    else:
        return "Error: Division by zero"
"""

# TODO: Import the custom module and use its functions
from math_operations import add,subtract,multiply,divide

# TODO: Use a while loop to create a simple calculator
def simple_calculator():
    while True:  
        num1 = float(input("Enter first number: "))
        num2 = float(input("Enter second number: "))

        operation = input('Enter a operation /,+,-,*: ')

        if operation == '+':
            print(add(num1,num2))
        elif operation == '-':
            print(subtract(num1,num2))
        elif operation == '*':
            print(multiply(num1,num2))
        elif operation == '/':
            print(divide(num1,num2))
        else:
            print('Enter valid number!')
simple_calculator()

